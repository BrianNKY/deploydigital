// Init bootstrap material design

$(document).ready(function () {
    $('body').bootstrapMaterialDesign();
});
